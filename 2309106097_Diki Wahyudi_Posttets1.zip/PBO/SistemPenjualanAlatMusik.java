import java.util.ArrayList;
import java.util.Scanner;

class AlatMusik {
    private String id;
    private String nama;
    private double harga;

    public AlatMusik(String id, String nama, double harga) {
        this.id = id;
        this.nama = nama;
        this.harga = harga;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public double getHarga() {
        return harga;
    }

    public void setHarga(double harga) {
        this.harga = harga;
    }

    @Override
    public String toString() {
        return "ID: " + id + ", Nama: " + nama + ", Harga: Rp" + harga;
    }
}

public class SistemPenjualanAlatMusik {
    private static ArrayList<AlatMusik> daftarAlatMusik = new ArrayList<>();
    private static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        while (true) {
            System.out.println("\n=== Sistem Penjualan Alat Musik Berbasis Website ===");
            System.out.println("1. Tambah Alat Musik");
            System.out.println("2. Lihat Daftar Alat Musik");
            System.out.println("3. Update Alat Musik");
            System.out.println("4. Hapus Alat Musik");
            System.out.println("5. Keluar");
            System.out.print("Pilih menu: ");
            int pilihan = scanner.nextInt();
            scanner.nextLine(); // Membersihkan newline

            switch (pilihan) {
                case 1:
                    tambahAlatMusik();
                    break;
                case 2:
                    lihatDaftarAlatMusik();
                    break;
                case 3:
                    updateAlatMusik();
                    break;
                case 4:
                    hapusAlatMusik();
                    break;
                case 5:
                    System.out.println("Terima kasih telah menggunakan sistem ini. Sampai jumpa!");
                    System.exit(0);
                default:
                    System.out.println("Pilihan tidak valid. Silakan coba lagi.");
            }
        }
    }

    private static void tambahAlatMusik() {
        System.out.print("Masukkan ID Alat Musik: ");
        String id = scanner.nextLine();
        System.out.print("Masukkan Nama Alat Musik: ");
        String nama = scanner.nextLine();
        System.out.print("Masukkan Harga Alat Musik: ");
        double harga = scanner.nextDouble();
        scanner.nextLine(); // Membersihkan newline

        AlatMusik alatMusik = new AlatMusik(id, nama, harga);
        daftarAlatMusik.add(alatMusik);
        System.out.println("Alat Musik berhasil ditambahkan!");
    }

    private static void lihatDaftarAlatMusik() {
        if (daftarAlatMusik.isEmpty()) {
            System.out.println("Daftar Alat Musik kosong.");
        } else {
            System.out.println("\nDaftar Alat Musik:");
            for (AlatMusik alatMusik : daftarAlatMusik) {
                System.out.println(alatMusik);
            }
        }
    }

    private static void updateAlatMusik() {
        System.out.print("Masukkan ID Alat Musik yang ingin diupdate: ");
        String id = scanner.nextLine();

        for (AlatMusik alatMusik : daftarAlatMusik) {
            if (alatMusik.getId().equals(id)) {
                System.out.print("Masukkan Nama Baru: ");
                String namaBaru = scanner.nextLine();
                System.out.print("Masukkan Harga Baru: ");
                double hargaBaru = scanner.nextDouble();
                scanner.nextLine(); // Membersihkan newline

                alatMusik.setNama(namaBaru);
                alatMusik.setHarga(hargaBaru);
                System.out.println("Alat Musik berhasil diupdate!");
                return;
            }
        }
        System.out.println("Alat Musik dengan ID " + id + " tidak ditemukan.");
    }

    private static void hapusAlatMusik() {
        System.out.print("Masukkan ID Alat Musik yang ingin dihapus: ");
        String id = scanner.nextLine();

        for (AlatMusik alatMusik : daftarAlatMusik) {
            if (alatMusik.getId().equals(id)) {
                daftarAlatMusik.remove(alatMusik);
                System.out.println("Alat Musik berhasil dihapus!");
                return;
            }
        }
        System.out.println("Alat Musik dengan ID " + id + " tidak ditemukan.");
    }
}